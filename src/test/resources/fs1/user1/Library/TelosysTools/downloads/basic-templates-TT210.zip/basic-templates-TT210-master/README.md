Set of basic templates usable with code generator TelosysTools ver 2.0.6

( https://sites.google.com/site/telosystools/ )

With package variables ( $ROOT_PKG and $ENTITY_PKG )
